function saveData()
        {
        let name =document.getElementById("username").value;
        localStorage.setItem("userName", name);
        document.getElementById("display").innerText = name ? "Welcome, " + name + "!" : "Please enter your name.";
        }
        function loadData()
        {
        let name = localStorage.getItem("userName");
        document.getElementById("display").innerText = name ? "Welcome, " + name : "No data saved!";
        }
        
// Load saved preferences
window.onload = function() {

    let savedName = localStorage.getItem("userName");
    let savedTheme = localStorage.getItem("theme");
    let savedLanguage = localStorage.getItem("language");
    // localStorage.removeItem("userName");

    if (savedName) {
        loadData();
    }
    if (savedTheme == "dark") {
        document.body.classList.add("dark");
    }
    if (savedTheme) {
        document.getElementById("theme").value = savedTheme;
    }
    if (savedLanguage) {
        document.getElementById("language").value = savedLanguage;
        changeLanguage(savedLanguage);
    }
};

// Save preferences
function savePreferences() {
    let theme = document.getElementById("theme").value;
    let language = document.getElementById("language").value;

    // Save to Local Storage
    localStorage.setItem("theme", theme);
    localStorage.setItem("language", language);

    // Change theme
    if (theme == "dark") {
        document.body.classList.add("dark");
    } else {
        document.body.classList.remove("dark");
    }
    // Change language
    changeLanguage(language);

    document.getElementById("message").textContent =
        "Preferences saved!";
}

// Change language
function changeLanguage(language) {
    let translations = {
        english: {
            title: "Weather Website",
            home: "Home",
            preferences: "Preferences",
            weather: "Weather",
            map: "Map",
            welcome: "WELCOME TO MY WEB PAGE!"
        },
        filipino: {
            title: "Website ng Panahon",
            home: "Tahanan",
            preferences: "Mga Kagustuhan",
            weather: "Panahon",
            map: "Mapa",
            welcome: "MALIGAYANG PAGDATING!"
        },
        spanish: {
            title: "Sitio del Clima",
            home: "Inicio",
            preferences: "Preferencias",
            weather: "Clima",
            map: "Mapa",
            welcome: "¡BIENVENIDO A MI PÁGINA WEB!"
        }
    };

    let selectedLanguage = translations[language] || translations.english;

    document.getElementById("site-title").textContent = selectedLanguage.title;
    document.getElementById("nav-home").textContent = selectedLanguage.home;
    document.getElementById("nav-preferences").textContent = selectedLanguage.preferences;
    document.getElementById("nav-weather").textContent = selectedLanguage.weather;
    document.getElementById("nav-map").textContent = selectedLanguage.map;
    document.getElementById("welcome-message").textContent = selectedLanguage.welcome;
}

// Weather API
async function getWeather() {

    let city = document.getElementById("city").value;

    // Put your API key here
    let API_KEY = "YOUR_API_KEY";

    let url =
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`;

    try {

        let response = await fetch(url);
        let data = await response.json();

        document.getElementById("weatherCity").textContent =
            data.name;

        document.getElementById("temperature").textContent =
            "Temperature: " + data.main.temp + " °C";

        document.getElementById("description").textContent =
            "Weather: " + data.weather[0].description;

    } catch (error) {

        document.getElementById("weatherCity").textContent =
            "City not found.";

    }
}

function getWeather() {
            let city = document.getElementById("city").value;
            let apiKey = "82ee6423748cc01d1cb1ca9793cbf2c4"; // Replace with your OpenWeatherMap API key
            let url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
 
        fetch(url)
             .then(response => response.json())
             .then(data => {
                 document.getElementById("weatherResult").innerHTML = `
             <p>Temperature: ${data.main.temp}°C</p>
            <img src="https://openweathermap.org/img/w/${data.weather[0].icon}.png">
            <p>${data.weather[0].description}</p>
            `;
          })
                .catch(error => console.error("Error fetching weather data:", error));
        }
    
